<?php
$lang = array(
    "title" => "Hlavná stránka",
    "nav1" => "Hlavná stránka",
    "nav2" => "Tlmič",
    "nav3" => "Gulička",
    "nav4" => "Kyvadlo",
    "nav5" => "Lietadlo",
    "nav6" => "Štatistika",
    "nav7" => "Informácie",
    "lang_sk" => "Slovensky",
    "lang_en" => "English",
    "r" => "Uhol",
    "popis" => "Zadajte rozsah pd 0 po 285",
    "csv" => "Stiahni záznam",
    "canvas" => "Animácia",
    "graf1" => "Graf uhla lietadla",
    "graf2" => "Graf uhla chvosta",
    "new" => "Nová pozícia",
    "old" => "Stará pozícia"

);
?>