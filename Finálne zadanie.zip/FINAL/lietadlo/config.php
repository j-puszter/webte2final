<?php
    session_start();

$servername = "localhost";
$username = "xdomorakm";
$password = "focal_pasame";
$dbname = "final";


$conn = new mysqli($servername, $username, $password, $dbname);

mysqli_set_charset($conn, "utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>

