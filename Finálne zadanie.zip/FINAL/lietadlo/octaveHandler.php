<?php

function checkInputValidity ($newR) {
    if (is_numeric($newR)) {
        return true;
    }
    else {
        return false;
    }
}

function executeCommand($site, $command, $newR, $oldR) {
    //include 'logging.php';
    
    
    echo ("New: " . $newR . " Old: " . $oldR);
    
    $Time = array();
    $airplaneAngle = array();
    $elevatorAngle = array();
    
    if (checkInputValidity($newR)) {
        $cmd = "octave -qf lietadlo.m " . $oldR . " " . $newR;
        exec ($cmd, $output);
        log_Data($site, $cmd, 0);
    }
    else {
        log_Data($site, $cmd, 3);
    }
    
    
    foreach ($output as $line) {
        $coords = explode(" ", trim($line));
        //echo ("T: " .  $coords[0] . ";\t Airplane Anglee= " . $coords[1] . "\t Elevator Angle= " . $coords[2] . "<br>");
        array_push($Time, $coords[0]);
        array_push($airplaneAngle, $coords[1]);
        array_push($elevatorAngle, $coords[2]);
    }

    $airplaneData = array('Time' => $Time, 'airplaneAngle' => $airplaneAngle, 'elevatorAngle' => $elevatorAngle);
    return $airplaneData;
    
}
    
    
    
?>