<!DOCTYPE html>
<html lang="utf-8">
    
<?php
    include 'lang_lietadlo.php';
    include 'octaveHandler.php';
    include 'logging.php';
    include 'config.php';
?>

<head>
    <title><?php echo $lang['nav5'] ?></title>
    <script src='https://cdn.plot.ly/plotly-latest.min.js'></script>
    <script src='fabric.min.js'></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        #footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            color: white;
            text-align: center;
        }
    </style>
    <?php
        $currentR = 0; 
    ?>
    <script>
        function aktualizacia1(){
            if(document.getElementById("graph1").checked == false){
                document.getElementById("airplaneAngleGraph").style.display = "none";
            }else{
                document.getElementById("airplaneAngleGraph").style.display = "block";
            }
        }
        function aktualizacia2(){
            if(document.getElementById("graph2").checked == false){
                document.getElementById("elevatorAngleGraph").style.display = "none";
            }else{
                document.getElementById("elevatorAngleGraph").style.display = "block";
            }
        }
        function aktualizacia3(){
            if(document.getElementById("animation").checked == false){
                document.getElementById("airplaneAnimation").style.display = "none";
            }else{
                document.getElementById("airplaneAnimation").style.display = "block";
            }
        }
    </script>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Menu</a>
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/index.php"><?php echo $lang['nav1'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/tlmic/tlmenie_index.php"><?php echo $lang['nav2'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/gulicka/gulicka.php"><?php echo $lang['nav3'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/kyvadlo/pendulum.php"><?php echo $lang['nav4'] ?></a>
            <a class="nav-item nav-link active" href="http://147.175.121.210:8084/FINAL/lietadlo/lietadlo.php"><?php echo $lang['nav5'] ?><span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/statistika.php"><?php echo $lang['nav6'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/rozpis.php"><?php echo $lang['nav7'] ?></a>
        </div>
    </div>
</nav>

    <h1><?php echo $lang['nav5'] ?></h1>

    <label for="graph1"><?php echo $lang['graf1'] ?></label>
    <input type="checkbox" id="graph1" value="Canvas" checked="checked" onclick="aktualizacia1()">
    <label for="graph2"><?php echo $lang['graf2'] ?></label>
    <input type="checkbox" id="graph2" value="Graf1" checked="checked" onclick="aktualizacia2()">
    <label for="animation"><?php echo $lang['canvas'] ?></label>
    <input type="checkbox" id="animation" value="Graf2" checked="checked" onclick="aktualizacia3()">


    <form class="form-group" method="post" action="lietadlo.php">
        <div class="form-group">
            <label for="oAngle"><?php echo $lang['old'] ?></label>
            <input type="text" id="oAngle" name="oAngle" readonly value="<?php if( isset( $_POST['nAngle'] )){ echo $_POST['nAngle']; $currentR = $_POST['oAngle']; } else { echo "0";} ?>"><br>
        </div>
        <div class="form-group">
            <label for="nAngle"><?php echo $lang['new'] ?></label>
            <input type="number" min="-45" max="45" step="any" id="nAngle" name="nAngle" value="<?php if( isset( $_POST['nAngle'] )){ echo $_POST['nAngle']; } else { echo "0";} ?>"><br>
        </div>
        <div class="form-group">
            <input class="btn btn-warning" type="submit" name="angle" value="<?php echo $lang['r'] ?>" />
        </div>
    </form>

    <div id='currentAngle' height="100"></div>
<div class="row">
	<div class="col-sm-6" id='airplaneAngleGraph' height="100"></div>
    <div class="col-sm-6" id='elevatorAngleGraph' height="100"></div>
</div>
    <canvas id="airplaneAnimation" width="1000" height="500" style="border:1px solid #000000;"></canvas>

    <?php
    
    if( isset( $_POST['nAngle'] )){
    	$airplaneData = executeCommand(4, "octave -qf lietadlo.m ", $_POST['nAngle'], $_POST['oAngle']);
    }
    ?>
    <script>
        //draw Airplane graph
        var trace1 = {
          x: [ <?php echo implode(", ", $airplaneData['Time']);  ?>],            
          y: [ <?php echo implode(", ", $airplaneData['airplaneAngle']); ?>],
          type: 'scatter' 
        };                
        var data = [trace1];
        Plotly.newPlot('airplaneAngleGraph', data);
    </script>
    
    <script>
        //draw Elevator graph
        var trace1 = {
          x: [ <?php echo implode(", ", $airplaneData['Time']);  ?>],            
          y: [ <?php echo implode(", ", $airplaneData['elevatorAngle']); ?>],
          type: 'scatter' 
        };                
        var data = [trace1];
        Plotly.newPlot('elevatorAngleGraph', data);
    </script>
    
    <script>
        
        function animateAircraft(i, img, animationDuration) {
            setTimeout(function() {
                img.animate('angle',airplaneAngle[i]* multiplier,{
                    onChange: canvas.renderAll.bind(canvas),
                    duration: animationDuration
                });
                console.log(i + " setting angle to: " + airplaneAngle[i]* multiplier);
            }, animationDuration*i);  
        }
        
        function animateElevator(i, img, animationDuration) {
            setTimeout(function() {
                img.animate('angle',elevatorAngle[i]* multiplier,{
                    onChange: canvas.renderAll.bind(canvas),
                    duration: animationDuration
                });
                //console.log(i + " setting angle to: " + elevatorAngle[i]* multiplier);
            }, animationDuration*i);  
        }
        
        
        
        var airplaneAngle = <?php echo json_encode($airplaneData['airplaneAngle']); ?>;
        var elevatorAngle = <?php echo json_encode($airplaneData['elevatorAngle']); ?>;
        var airplane = new Image();
        var canvas = new fabric.Canvas('airplaneAnimation');
        
        var multiplier = 1;
        var animationDuration = 50;
        console.log(<?php echo ($currentR); ?>);
        fabric.Image.fromURL('airplane.png', function(img){
            img.originX = "center";
            img.originY = "center";
            img.left = 650;
            img.top = 350;
            img.angle = <?php echo ($currentR); ?>;
            canvas.add(img);
            canvas.sendToBack(img);
            canvas.item(0).selectable = false;
            
            for (i = 1; i < airplaneAngle.length-1; i++) {
                animateAircraft(i, img, animationDuration);
            }
        });    
        
        fabric.Image.fromURL('Elevator.png', function(img){
            img.originX = "center";
            img.originY = "center";
            img.left = 650;
            img.top = 350;
            canvas.bringToFront(img);
            canvas.add(img);
            canvas.item(1).selectable = false;
            
            for (i = 1; i < elevatorAngle.length-1; i++) {
                animateElevator(i, img, animationDuration);
            }
        });
    </script>
    <div id="footer" class="footer bg-dark text-center">
        <a href="lietadlo.php?lang=sk"><img border="0" src="sk.jpg" width="60" height="30"></a>
        | <a href="lietadlo.php?lang=en"><img border="0" src="en.jpg" width="60" height="30"></a>
    </div>

</body>
