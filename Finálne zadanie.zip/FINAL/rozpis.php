<?php
include "lang.php";
?>
<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="utf-8">
    <title><?php echo $lang['nav7'] ?></title>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        #footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            color: white;
            text-align: center;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Menu</a>
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/index.php"><?php echo $lang['nav1'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/tlmic/tlmenie_index.php"><?php echo $lang['nav2'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/gulicka/gulicka.php"><?php echo $lang['nav3'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/kyvadlo/pendulum.php"><?php echo $lang['nav4'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/lietadlo/lietadlo.php"><?php echo $lang['nav5'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/statistika.php"><?php echo $lang['nav6'] ?></a>
            <a class="nav-item nav-link active" href="http://147.175.121.210:8084/FINAL/rozpis.php"><?php echo $lang['nav7'] ?><span class="sr-only">(current)</span></a>
        </div>
    </div>
</nav>
<h1 style="text-align: center"><?php echo $lang['nadpis'] ?></h1>
<h3 style="text-align: center"><?php echo $lang['tabulka_nadpis'] ?></h3>
<table class="table table-dark">
    <tr>
        <th><?php echo $lang['uloha'] ?></th>
        <th>Juraj Puszter</th>
        <th>Matúš Domorák</th>
        <th>Martin Borovanský</th>
        <th>Tibor Csicsay</th>
    </tr>
    <tr>
        <td><?php echo $lang['kyvadlo'] ?></td>
        <td>X</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td><?php echo $lang['gulicka'] ?></td>
        <td></td>
        <td>X</td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td><?php echo $lang['lietadlo'] ?></td>
        <td></td>
        <td></td>
        <td>X</td>
        <td></td>
    </tr>
    <tr>
        <td><?php echo $lang['tlmic'] ?></td>
        <td></td>
        <td></td>
        <td></td>
        <td>X</td>
    </tr>
    <tr>
        <td><?php echo $lang['cas'] ?></td>
        <td>X</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td><?php echo $lang['log'] ?></td>
        <td></td>
        <td></td>
        <td>X</td>
        <td></td>
    </tr>
    <tr>
        <td>CSS</td>
        <td></td>
        <td>X</td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td><?php echo $lang['web'] ?></td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td></td>
    </tr>
    <tr>
        <td><?php echo $lang['language'] ?></td>
        <td></td>
        <td>X</td>
        <td></td>
        <td></td>
    </tr>
</table>
<h2><?php echo $lang['APIheader'] ?></h2>
<p><?php echo $lang['APIcontent'] ?></p>
<div>
    <?php echo $lang['APIdn'] ?>
</div>
<br>
<br>
<br>
<br>
<div id="footer" class="footer bg-dark text-center">
    <a href="rozpis.php?lang=sk"><img border="0" src="sk.jpg" width="60" height="30"></a>
    | <a href="rozpis.php?lang=en"><img border="0" src="en.jpg" width="60" height="30"></a>
</div>
</body>
</html>
