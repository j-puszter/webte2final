<?php
include "lang_gulicka.php";
include "config_gulicka.php";
try{
    $conn = new mysqli($servername, $username, $password, $dbname);
    mysqli_set_charset($conn, "utf-8");
}catch(mysqli_sql_exception $e){
    echo "Zlyhalo pripojenie: " . $e->getMessage();
    exit();
}
$site = 2;
/*  $Site = Site of origin of the request
    0 = Main site
    1 = Kyvadlo
    2 = Gulicka
    3 = Tlmic
    4 = Lietadlo

    $Request = Command, which was executed by octave
    i.e.  "octave -qf lietadlo.m 0.2"

    #Error = Execution status of the request
    0 = Execution successful
    1 = Error
    2 = Warning
    3 = Invalid input values

    $Desc = Description of the error, based on $Error

*/
?>

<!DOCTYPE html>
<html lang="sk">
    <head>
        <meta charset="utf-8">
        <title><?php echo $lang['nav3'] ?></title>
        <script src='fabric.min.js'></script>
        <script src='https://cdn.plot.ly/plotly-latest.min.js'></script>
        <style>
            #footer {
                position: fixed;
                left: 0;
                bottom: 0;
                width: 100%;
                color: white;
                text-align: center;
            }
        </style>
        <?php
            $currentR = 0;
        ?>
        <script>
            function aktualizacia1(){
                if(document.getElementById("a1").checked == false){
                    document.getElementById("tyckadiv").style.display = "none";
                }else{
                    document.getElementById("tyckadiv").style.display = "block";
                }
            }
            function aktualizacia2(){
                if(document.getElementById("a2").checked == false){
                    document.getElementById("graf").style.display = "none";
                }else{
                    document.getElementById("graf").style.display = "block";
                }
            }
            function aktualizacia3(){
                if(document.getElementById("a3").checked == false){
                    document.getElementById("graf2").style.display = "none";
                }else{
                    document.getElementById("graf2").style.display = "block";
                }
            }
        </script>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    </head>
    <body>
    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Menu</a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/index.php"><?php echo $lang['nav1'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/tlmic/tlmenie_index.php"><?php echo $lang['nav2'] ?></a>
                <a class="nav-item nav-link active" href="http://147.175.121.210:8084/FINAL/gulicka/gulicka.php"><?php echo $lang['nav3'] ?><span class="sr-only">(current)</span></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/kyvadlo/pendulum.php"><?php echo $lang['nav4'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/lietadlo/lietadlo.php"><?php echo $lang['nav5'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/statistika.php"><?php echo $lang['nav6'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/rozpis.php"><?php echo $lang['nav7'] ?></a>
            </div>
        </div>
    </nav>
        <h1><?php echo $lang['nav3'] ?></h1>

        <form class="form-group" method="post" action="gulicka.php">
            <div class="form-group">
                <div class="form-group">
                    <label for="staraR"><?php echo $lang['old'] ?></label><br>
                    <input type="text" id="staraR" name="staraR" readonly value="<?php if( isset( $_POST['poziciaR'] )){ echo $_POST['poziciaR']; $currentR = $_POST['staraR']; } else { echo "0";} ?>"><br>
                </div>
                <div class="form-group">
                <label for="poziciaR"><?php echo $lang['new'] ?></label><br><input type="number" step="any" id="poziciaR" name="poziciaR" value="<?php if( isset( $_POST['nAngle'] )){ echo $_POST['nAngle']; } else { echo "";} ?>" min="0" max="285"><br></div>
                    <br>
                <input class="btn btn-success" type="submit" name="pozicia" value="<?php echo $lang['r'] ?>">
            </div>
        </form>

        <label for="a1"><?php echo $lang['canvas'] ?></label><input type="checkbox" id="a1" value="Canvas" checked="checked" onclick="aktualizacia1()">
        <label for="a2"><?php echo $lang['graf1'] ?></label><input type="checkbox" id="a2" value="Graf1" checked="checked" onclick="aktualizacia2()">
        <label for="a3"><?php echo $lang['graf2'] ?></label><input type="checkbox" id="a3" value="Graf2" checked="checked" onclick="aktualizacia3()">
        <?php

        ?>
        <div id="tyckadiv">
            <canvas id="tycka" width="800" height="500" style="border:1px solid #000000;"></canvas>
        </div>
        <br>
        <div class="row">
            <div class="col-sm-6" id="graf"></div>
            <div class="col-sm-6" id="graf2"></div>
        </div>
        <?php
            if(isset($_POST['poziciaR'])){
                if(checkInput($_POST['poziciaR'])){
                    var_dump($_POST['poziciaR']);
                    var_dump($_POST['staraR']);
                    $cmd =  "octave -qf gulicka.txt " . $_POST['poziciaR'] . " " . $_POST['staraR'];
                    //echo($cmd . "<br>");
                    exec($cmd,$output);
                    login($site, $cmd,0, $conn);
                }else{
                    $cmd =  "octave -qf gulicka.txt " . $_POST['poziciaR'] . " " . $_POST['staraR'];
                    //echo($cmd . "<br>");
                    exec($cmd,$output);
                    login($site, $cmd,3, $conn);
                }

                $array = array();
                $array1 = array();
                $array2 = array();

                foreach ($output as $line){
                    $trimmed= explode(" ",trim($line));
                    $filtered = array_filter($trimmed);
                    $result = array_values($filtered);
                    //echo "t: " . $result[0] . "; x: " . $result[1] . "; y: " . $result[2] . "<br>";
                    array_push($array1, $result[1]);
                    array_push($array2, rad2deg($result[2]));
                    array_push($array,$result[0]);
                }
            }

        echo ("<script>");
        echo ("var trace1 = {                \n");
        echo ("  x: ["); echo implode(", ", $array); echo ("], \n");
        echo ("  y: ["); echo implode(", ", $array1); echo ("], \n");
        echo ("  type: 'scatter'             \n");
        echo ("};                            \n");
        echo ("var data = [trace1];         \n");
        echo ("                              \n");
        echo ("Plotly.newPlot('graf', data);\n");
        echo ("</script>");

        echo ("<script>");
        echo ("var trace1 = {                \n");
        echo ("  x: ["); echo implode(", ", $array); echo ("], \n");
        echo ("  y: ["); echo implode(", ", $array2); echo ("], \n");
        echo ("  type: 'scatter'             \n");
        echo ("};                            \n");
        echo ("var data = [trace1];         \n");
        echo ("                              \n");
        echo ("Plotly.newPlot('graf2', data);\n");
        echo ("</script>");



        ?>
<?php
    function login($site, $request, $error, $conn){
        $description = "";
        switch($error){
            case 0:
                $description = "Script execution succesful";
                break;
            case 1:
                $description = "Script execution failed";
                break;
            case 2:
                $description = "Warnings";
                break;
            case 3:
                $description = "Invalid input values";
                break;
        }

        $sql = "insert into login (site,request,time,value,description)
        values ('$site','$request',CURRENT_TIME , '$error','$description')";
        if (mysqli_query($conn, $sql)) {
            //echo "Record updated successfully";
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }

    function checkInput($r){
        if(is_numeric($r))
            return true;
        else
            return false;
    }

    $currentR = 0;
?>
        <script>
            var uholtycky = <?php echo json_encode($array2); ?>;
            var poziciagulicky = <?php echo json_encode($array1); ?>;
            var tyc = new Image();
            var canvas = new fabric.Canvas('tycka');
            var multiplier = 1;
            var trvanie = 50;

            var gulicka = new fabric.Circle({
                radius: 25,
                left: -285,
                top: -35,
                fill: 'green',
                originX: 'center',
                originY: 'center'
            });

            var tycka = new fabric.Rect({
                width: 600,
                height: 20,
                fill: 'black',
                originX: 'center',
                originY: 'center'
            });

            var group = new fabric.Group([ gulicka, tycka ], {
                left: 85,
                top: 200
            });

            canvas.add(group);
            canvas.item(0).selectable = false;

            for (i = 1; i < uholtycky.length-1; i++) {
                palicka(i, group, trvanie);
                gulickaside(i, gulicka, trvanie);
            }
            function palicka(i, group, trvanie) {
                setTimeout(function() {
                    group.animate('angle',uholtycky[i]* multiplier,{
                        onChange: canvas.renderAll.bind(canvas),
                        duration: trvanie
                    });
                }, trvanie*i);
            }

            function gulickaside(i, gulicka, trvanie) {
                setTimeout(function() {
                    gulicka.animate('left',(poziciagulicky[i]-285)* multiplier,{
                        onChange: canvas.renderAll.bind(canvas),
                        duration: trvanie
                    });
                    console.log(i + " setting R to: " + poziciagulicky[i]* multiplier);
                }, trvanie*i);
            }
        </script>

    <div id="footer" class="footer bg-dark text-center">
        <a href="gulicka.php?lang=sk"><img border="0" src="sk.jpg" width="60" height="30"></a>
        | <a href="gulicka.php?lang=en"><img border="0" src="en.jpg" width="60" height="30"></a>
    </div>
    </body>
</html>