<?php
$lang = array(
    "title" => "Hlavná stránka",
    "nav1" => "Hlavná stránka",
    "nav2" => "Tlmič",
    "nav3" => "Gulička",
    "nav4" => "Kyvadlo",
    "nav5" => "Lietadlo",
    "nav6" => "Štatistika",
    "nav7" => "Informácie",
    "lang_sk" => "Slovensky",
    "lang_en" => "English",
    "r" => "Pozícia R",
    "popis" => "Zadajte rozsah pd 0 po 285",
    "csv" => "Stiahni CSV",
    "canvas" => "Canvas",
    "graf1" => "Graf1",
    "graf2" => "Graf2",
    "new" => "Nová pozícia",
    "old" => "Stará pozícia"

);
?>