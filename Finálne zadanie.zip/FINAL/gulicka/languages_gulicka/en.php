<?php
$lang = array(
    "title" => "Main website",
    "nav1" => "Main website",
    "nav2" => "Silencer",
    "nav3" => "Ball",
    "nav4" => "Pendulum",
    "nav5" => "Plane",
    "nav6" => "Statistic",
    "nav7" => "Information",
    "lang_sk" => "Slovensky",
    "lang_en" => "English",
    "r" => "Position R",
    "popis" => "Enter range from 0 to 285",
    "csv" => "Download CSV",
    "canvas" => "Canvas",
    "graf1" => "Graph1",
    "graf2" => "Graph2",
    "new" => "New Position",
    "old" => "Old Position"
);
?>