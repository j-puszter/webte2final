<?php
    include "lang.php";
    include 'kyvadlo/logging.php';
include "config.php";

ob_start();

if( isset( $_POST['download'] )){
    csvExport($conn);
}


function fetch_data($conn){
    $out = '';
    $sql =  "Select * FROM login order by id asc";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_array($result)){
        $out .= '<tr>
                             <td>'.$row['id'].'</td>
                             <td>'.$row['site'].'</td>
                             <td>'.$row['request'].'</td>
                             <td>'.$row['time'].'</td>
                             <td>'.$row['value'].'</td>
                             <td>'.$row['description'].'</td>
                         </tr>';
    }

    return $out;
}

if(isset($_POST["generatePDF"])){
    require_once 'tcpdf/tcpdf.php';
    $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $obj_pdf->SetCreator(PDF_CREATOR);
    $obj_pdf->SetTitle($lang['titlePDF']);
    $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);
    $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    $obj_pdf->SetDefaultMonospacedFont('helvetica');
    $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);
    $obj_pdf->setPrintHeader(false);
    $obj_pdf->setPrintFooter(false);
    $obj_pdf->SetAutoPageBreak(TRUE, 10);
    $obj_pdf->SetFont('helvetica', '', 11);
    $obj_pdf->AddPage();
    $content = '';
    $content .= '
    <h4 align="center">Generated PDF from MYSQL Using TCPDF in PHP</h4><br>
    <table border="1" cellspacing="0" cellpadding="3">
        <tr>
            <th width="5%">ID</th>
            <th width="5%">SITE</th>
            <th width="25%">REQUEST</th>
            <th width="10%">TIME</th>
            <th width="10%">VALUE</th>
            <th width="45%">DESCRIPTION</th>
        </tr>
    ';
    $content .= fetch_data($conn);
    $content .= '</table>';
    $obj_pdf->writeHTML($content);
    $obj_pdf->Output('MYSQLTable.pdf', 'D');
}
?>
<!DOCTYPE html>
<html lang="sk">
    <head>
        <title><?php echo $lang['title'] ?></title>
        <meta charset="UTF-8">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <style>
            #footer {
                position: fixed;
                left: 0;
                bottom: 0;
                width: 100%;
                color: white;
                text-align: center;
            }
        </style>
        <script>
            if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
            }
        </script>
    </head>
    <body>

    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Menu</a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link active" href="http://147.175.121.210:8084/FINAL/index.php"><?php echo $lang['nav1'] ?><span class="sr-only">(current)</span></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/tlmic/tlmenie_index.php"><?php echo $lang['nav2'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/gulicka/gulicka.php"><?php echo $lang['nav3'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/kyvadlo/pendulum.php"><?php echo $lang['nav4'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/lietadlo/lietadlo.php"><?php echo $lang['nav5'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/statistika.php"><?php echo $lang['nav6'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/rozpis.php"><?php echo $lang['nav7'] ?></a>
            </div>
        </div>
    </nav>

    <form class="form-group" method="post" action="index.php">
        <br>
        <div class="form-group">
            <label id="label1" for="sCommand"><?php echo $lang['description'] ?></label>
            <input class="form-control" type="text" id="sCommand" name="sCommand"><br>
        </div>
        <div class="form-group">
            <input class="btn btn-primary" type="submit" name="Command" value="<?php echo $lang['button'] ?>" />
        </div>
    </form>

    <?php
    if(isset( $_POST['sCommand'] )){

        $command = "octave -qf --eval " . $_POST['sCommand'];
        echo($command . "<br>");
        exec($command, $output);
        log_Data(0, $command, 0);
        foreach ($output as $line) {
            echo ($line . "<br>");
        }
    }
    ?>

    <form class="form-group" method="post" action="index.php">
        <input class="btn btn-primary" type="submit" name="download" value="<?php echo $lang['csv'] ?>" />
    </form>

    <form class="form-group" method="post">
        <input type="submit" name="generatePDF" id="generatePDF" class="btn btn-primary" value="<?php echo $lang['pdf'] ?>">
    </form>

    <div id="footer" class="footer bg-dark text-center">
        <a href="index.php?lang=sk"><img border="0" src="sk.jpg" width="60" height="30"></a>
        | <a href="index.php?lang=en"><img border="0" src="en.jpg" width="60" height="30"></a>
    </div>
    </body>
</html>
