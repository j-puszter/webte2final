<?php
$lang = array(
    "title" => "Hlavná stránka",
    "nav1" => "Hlavná stránka",
    "nav2" => "Tlmič",
    "nav3" => "Gulička",
    "nav4" => "Kyvadlo",
    "nav5" => "Lietadlo",
    "nav6" => "Štatistika",
    "nav7" => "Informácie",
    "description" => "Zadaj príkaz pre Octave(help, 1+1, atď.)",
    "button" => "Spusti",
    "octave" => "Octave",
    "pocet" => "Počet",
    "1" => "Octave príkaz",
    "2" => "Tlmič",
    "3" => "Gulička",
    "4" => "Kyvadlo",
    "5" => "Lietadlo",
    "csv" => "Stiahni tabulku ako CSV",
    "pdf" => "Stiahni tabulku ako PDF",
    "titlePDF" => "Generovaná MYSQL tabuľka do PDF za použitia TCPDF",
    "lang_sk" => "Slovensky",
    "lang_en" => "English",
    "nadpis" => "WT2 Finálne Zadanie",
    "tabulka_nadpis" => "Rozvrh prác",
    "uloha" => "Úloha",
    "kyvadlo" => "Inverzné kyvadlo",
    "gulicka" => "Gulička na tyči",
    "lietadlo" => "Náklon lietadla",
    "tlmic" => "Tlmič auta",
    "cas" => "CAS popžiadavky",
    "log" => "Logovanie",
    "web"=>"Webová stránka",
    "language" => "Multi jazyčnoosť",
    "mail"=>"Odošli na mail",
    "APIheader" => "Popis API",
    "APIcontent" => "<strong>kyvadlo</strong> - vstup: požadovaná nová poloha kyvadla r, výstup: aktuálna pozícia kyvadla x(:,1) a aktuálny uhol kyvadla (náklon vertikálnej tyče – uhol v radiánoch) x(:,3)<br>
                     <strong>gulička na tyči</strong> - vstup: požadovaná nová poloha guličky na tyči r, výstup: aktuálna pozícia guličky N*x(:,1) a aktuálny náklon tyče (uhol v radiánoch) x(:,3)<br>
                     <strong>tlmič auta</strong>> – vstup: požadovaná výška skokovej prekážky r, výstup: aktuálna pozícia vozidla x(:,1) a aktuálna pozícia kolesa x(:,3)<br>
                     <strong>náklon lietadla</strong> – vstup: požadovaný nový náklon lietadla r, výstup: aktuálny náklon lietadla x(:,3) a aktuálny náklon zadnej klapky r*ones(size(t))*N-x*K'    
                    ",
    "mailsucces" => "Mail bol odoslaný",
    "mailfailed" => "Ooops! Niekde sa stala chyba.",
    "subject" => "Štatistika",
    "APIdn" => "<a href=\"pdfsk.pdf\" download>Stiahnuť popis ako PDF</a>"
);
?>