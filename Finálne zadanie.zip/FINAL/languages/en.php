<?php
$lang = array(
    "title" => "Main website",
    "nav1" => "Main website",
    "nav2" => "Silencer",
    "nav3" => "Ball",
    "nav4" => "Pendulum",
    "nav5" => "Plane",
    "nav6" => "Statistic",
    "nav7" => "Information",
    "description" => "Enter the command for Octave(help, 1+1, etc.)",
    "button" => "Run",
    "octave" => "Octave",
    "pocet" => "Count",
    "1" => "Octave command",
    "2" => "Silencer",
    "3" => "Ball",
    "4" => "Pendulum",
    "5" => "Plane",
    "lang_sk" => "Slovensky",
    "lang_en" => "English",
    "nadpis" => "WT2 Final Task",
    "tabulka_nadpis" => "Work schedule",
    "uloha" => "Task",
    "kyvadlo" => "Reverse Pendulum",
    "gulicka" => "Ball on stick",
    "lietadlo" => "Tilt of the plane",
    "tlmic" => "Car silencer",
    "csv" => "Download table as CSV",
    "pdf" => "Download table as PDF",
    "cas" => "CAS requirements",
    "log" => "Logs",
    "titlePDF" => "Generated MYSQL table into PDF using TCPDF",
    "web"=>"Web Site",
    "language" => "Multi language",
    "mail"=>"Send to mail",
    "APIheader" => "Description API",
	"APIcontent" => "<strong>pendulum</strong> - input: required new position of the pendulum r, output: actual position of the pendulum x(:,1) and actual angle of the pendulum (tilt of the vertical rod – angle in radians) x(:,3)<br>
                     <strong>ball on the rod</strong> - input: required new position of the ball on the rod r, output: actual position of the ball N*x(:,1) and actual angle of the rod (angle in radians) x(:,3)<br>
                     <strong>car damper</strong> – input: required height of jumping obstacle r, output: actual position of the vehicle x(:,1) and actual position of the tire x(:,3)<br>
                     <strong>tilt of the plane</strong> – input: required new tilt of the plane r, output: actual tilt of the plane x(:,3) and actual tilt of the rear flap r*ones(size(t))*N-x*K'    
                    ",
    "mailsucces" => "Mail was send",
    "mailfailed" => "Ooops! Somwhere mistake happend.",
    "subject" => "Statistic",
    "APIdn" => "<a href=\"pdfen.pdf\" download>Download description as PDF</a>"
);
?>