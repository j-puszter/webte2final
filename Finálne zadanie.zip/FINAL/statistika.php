<?php
include "lang.php";
include "config.php";
?>
<!doctype>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title><?php echo $lang['nav6'] ?></title>
    <style>
        #footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            color: white;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Menu</a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/index.php"><?php echo $lang['nav1'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/tlmic/tlmenie_index.php"><?php echo $lang['nav2'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/gulicka/gulicka.php"><?php echo $lang['nav3'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/kyvadlo/pendulum.php"><?php echo $lang['nav4'] ?></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/lietadlo/lietadlo.php"><?php echo $lang['nav5'] ?></a>
                <a class="nav-item nav-link active" href="http://147.175.121.210:8084/FINAL/statistika.php"><?php echo $lang['nav6'] ?><span class="sr-only">(current)</span></a>
                <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/rozpis.php"><?php echo $lang['nav7'] ?></a>
            </div>
        </div>
    </nav>

    <table id="table" class="table table-dark">
        <thead>
        <tr>
            <th scope="col"><?php echo $lang['octave'] ?></th>
            <th scope="col"><?php echo $lang['pocet'] ?></th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th scope="row"><?php echo $lang['1'] ?></th>
            <td><?php $sql = "SELECT SITE, COUNT(SITE) as Visits FROM login where site = 0";
                $result = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_array($result)){
                    echo $row["Visits"];
                    $a1 = $row["Visits"];
                }
                ?></td>
        </tr>
        <tr>
            <th scope="row"><?php echo $lang['2'] ?></th>
            <td><?php $sql = "SELECT SITE, COUNT(SITE) as Visits FROM login where site = 1";
                $result = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_array($result)){
                    echo $row["Visits"];
                    $a2 = $row["Visits"];
                }
                ?></td>
        </tr>
        <tr>
            <th scope="row"><?php echo $lang['3'] ?></th>
            <td><?php $sql = "SELECT SITE, COUNT(SITE) as Visits FROM login where site = 2";
                $result = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_array($result)){
                    echo $row["Visits"];
                    $a3 = $row["Visits"];
                }
                ?></td>
        </tr>
        <tr>
            <th scope="row"><?php echo $lang['4'] ?></th>
            <td><?php $sql = "SELECT SITE, COUNT(SITE) as Visits FROM login where site = 3";
                $result = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_array($result)){
                    echo $row["Visits"];
                    $a4 = $row["Visits"];
                }
                ?></td>
        </tr>
        <tr>
            <th scope="row"><?php echo $lang['5'] ?></th>
            <td><?php $sql = "SELECT SITE, COUNT(SITE) as Visits FROM login where site = 4";
                $result = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_array($result)){
                    echo $row["Visits"];
                    $a5 = $row["Visits"];
                }
                ?></td>
        </tr>
        </tbody>
    </table>

    <form class="form-group" method="post" action="statistika.php">
        <input type="email" name="email"><br>
        <input class="btn btn-dark" type="submit" name="mail" value="<?php echo $lang['mail'] ?>">
    </form>

    <?php
    if(isset($_POST['mail'])) {
        $to      = $_POST['email'];
        $subject = $lang['subject'];
        $message = $lang['1'] . " " . $a1 . "\n" .
        $lang['2'] . " " . $a2 . "\n" .
        $lang['3'] . " " . $a3 . "\n" .
        $lang['4'] . " " . $a4 . "\n" .
        $lang['5'] . " " . $a5;

        $result = mail($to, $subject, $message);
        if ($result == true){
            echo $lang['mailsucces'];
        }else{
            echo $lang['mailfailed'];
        }
   }
    ?>

    <div id="footer" class="footer bg-dark text-center">
        <a href="statistika.php?lang=sk"><img border="0" src="sk.jpg" width="60" height="30"></a>
        | <a href="statistika.php?lang=en"><img border="0" src="en.jpg" width="60" height="30"></a>
    </div>
</body>
</html>
