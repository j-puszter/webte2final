<!DOCTYPE html>
<html lang="utf-8">
    
<?php
    include 'lang_kyvadlo.php';
    include 'octavePendulumHandler.php';
    include 'logging.php';
    include 'config.php';

?>

<head>
    <title><?php echo $lang['nav4'] ?></title>
    <script src='https://cdn.plot.ly/plotly-latest.min.js'></script>
    <script src='fabric.min.js'></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        #footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            color: white;
            text-align: center;
        }
    </style>
    <?php
        $currentR = 0;
    ?>

    <script>
        function showAnimation(){
            if(document.getElementById("animationCheckbox").checked){
                document.getElementById("pendulumAnimationVrapper").style.display = "block";
            }else{
                document.getElementById("pendulumAnimationVrapper").style.display = "none";

            }
        }
        function showGraph(){
            if(document.getElementById("graphCheckbox").checked){
                document.getElementById("pendulumGraph").style.display = "block";
            }else{
                document.getElementById("pendulumGraph").style.display = "none";
            }
        }
    </script>
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Menu</a>
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/index.php"><?php echo $lang['nav1'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/tlmic/tlmenie_index.php"><?php echo $lang['nav2'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/gulicka/gulicka.php"><?php echo $lang['nav3'] ?></a>
            <a class="nav-item nav-link active" href="http://147.175.121.210:8084/FINAL/kyvadlo/pendulum.php"><?php echo $lang['nav4'] ?><span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/lietadlo/lietadlo.php"><?php echo $lang['nav5'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/statistika.php"><?php echo $lang['nav6'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/rozpis.php"><?php echo $lang['nav7'] ?></a>
        </div>
    </div>
</nav>

    <h1><?php echo $lang['nav4'] ?></h1>

    <label for="animationCheckbox"><?php echo $lang['canvas'] ?></label>
    <input type="checkbox" id="animationCheckbox" value="showAnimation" checked onclick="showAnimation()">
    <label for="graphCheckbox"><?php echo $lang['graf'] ?></label>
    <input type="checkbox" id="graphCheckbox" value="showGraph" checked onclick="showGraph()">

    <form class="form-group" method="post" action="pendulum.php">
        <div class="form-group">
            <label for="oPosition"><?php echo $lang['old'] ?></label>
            <input type="text" id="oPosition" name="oPosition" readonly value="<?php if( isset( $_POST['nPosition'] )){ echo $_POST['nPosition']; $currentR = $_POST['oPosition']; } else { echo "0";} ?>"><br>
        </div>
        <div class="form-group">
            <label for="nPosition"><?php echo $lang['new'] ?></label>
            <input type="number" step="any" min="0" max="500" id="nPosition" name="nPosition" value="<?php if( isset( $_POST['nPosition'] )){ echo $_POST['nPosition']; } else { echo "0";} ?>"><br>
        </div>
        <div class="form-group">
            <input class="btn btn-danger" type="submit" name="position" value="<?php echo $lang['r'] ?>" />
        </div>
    </form>

    <div id='currentPosition' height="100"></div>
    <div id="pendulumAnimationVrapper"><canvas id="pendulumAnimation" width="1000" height="500" style="border:1px solid #000000;"></canvas></div>
    <div id='pendulumGraph' height="100"></div>
    <?php

    
    if( isset( $_POST['nPosition'] )){
    	$pendulumData = executeCommand($_POST['nPosition'], $_POST['oPosition']);
    }
    ?>
    <script>
        //Graf
        var trace1 = {
          x: [ <?php echo implode(", ", $pendulumData['time']);  ?>],
          y: [ <?php echo implode(", ", $pendulumData['position']); ?>],
          type: 'scatter' 
        };
        var trace2 = {
            x: [ <?php echo implode(", ", $pendulumData['time']);  ?>],
            y: [ <?php echo implode(", ", $pendulumData['angle']); ?>],
            type: 'scatter'
        };
        var data = [trace1, trace2];
        Plotly.newPlot('pendulumGraph', data);
    </script>

    <script>
        //Animacia
        function animateCart(i, img, animationDuration) {
            setTimeout(function() {
                img.animate('left',110 + cartPosition[i]* multiplier,{
                    onChange: canvas.renderAll.bind(canvas),
                    duration: animationDuration
                });
                //console.log(i + " setting angle to: " + cartPosition[i]* multiplier);
            }, animationDuration*i);
        }

        function animatePendulum(i, img, animationDuration) {
            setTimeout(function() {
                img.animate('angle', (-(pendulumAngle[i] * 180) / Math.PI ) / 30* multiplier,{
                    onChange: canvas.renderAll.bind(canvas),
                    duration: animationDuration
                });
                //console.log(i + " setting angle to: " + pendulumAngle[i]* multiplier);
            }, animationDuration*i);
        }

        var cartPosition = <?php echo json_encode($pendulumData['position']); ?>;
        var pendulumAngle = <?php echo json_encode($pendulumData['angle']); ?>;
        var canvas = new fabric.Canvas('pendulumAnimation');

        var multiplier = 1;
        var animationDuration = 50;
        //console.log(<?php echo ($currentR); ?>);
        fabric.Image.fromURL('cart.svg', function(img){
            img.originX = "center";
            img.originY = "center";
            img.left = 110;
            img.top = 350;
            img.position = <?php echo ($currentR); ?>;
            canvas.add(img);
            canvas.bringToFront(img);
            canvas.item(0).selectable = false;
            for (i = 1; i < cartPosition.length-1; i++) {
                animateCart(i, img, animationDuration);
            }
        });

        fabric.Image.fromURL('pendulum.svg', function(img){
            img.originX = "center";
            img.originY = "bottom";
            img.left = 110;
            img.top = 275;
            canvas.add(img)
            canvas.sendToBack(img);
            canvas.item(0).selectable = false;

            for (i = 1; i < pendulumAngle.length-1; i++) {
                animatePendulum(i, img, animationDuration);
                animateCart(i, img, animationDuration);
            }
        });
    </script>
    <div id="footer" class="footer bg-dark text-center">
        <a href="pendulum.php?lang=sk"><img border="0" src="sk.jpg" width="60" height="30"></a>
        | <a href="pendulum.php?lang=en"><img border="0" src="en.jpg" width="60" height="30"></a>
    </div>

</body>
