<?php

function checkInputValidity ($newR) {
    if (is_numeric($newR)) {
        return true;
    }
    else {
        return false;
    }
}

function executeCommand($newR, $oldR) {
    
    echo ("New: " . $newR . " Old: " . $oldR);

    $command = "octave -qf kyvadlo.txt ". $newR . " " . $oldR;

    if (checkInputValidity($newR)) {
        exec ($command, $output);
        log_Data(1, $command, 0);
    }
    else {
        log_Data(1, $command, 3);
    }
    $pendulumData = array(array());
    $counter = 0;
    foreach ($output as $line) {
        $trimmed = explode(" ", trim($line));
        $filtered = array_filter($trimmed);
        $result = array_values($filtered);
        $pendulumData['time'][$counter] = $result[0];
        $pendulumData['position'][$counter] = $result[1];
        $pendulumData['angle'][$counter] = $result[2];
        $counter++;
    }
    array_shift($pendulumData);
    return $pendulumData;
}
    
?>