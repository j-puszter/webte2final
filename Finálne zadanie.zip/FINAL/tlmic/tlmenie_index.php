<?php
include 'lang_tlmic.php';
include 'octaveHandler.php';
include 'logging.php';
try{
    $conn = new mysqli($servername, $username, $password, $dbname);
    mysqli_set_charset($conn, "utf8");
}catch(mysqli_sql_exception $e){
    echo "Zlyhalo pripojenie: " . $e->getMessage();
    exit();
}

session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <script src='https://cdn.plot.ly/plotly-latest.min.js'></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title><?php echo $lang['nav2']; ?></title>
    <style>
        #footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            color: white;
            text-align: center;
        }
    </style>
    <script>
        function aktualizacia1(){
            if(document.getElementById("animacia").checked == false){
                document.getElementById("canvasdiv").style.display = "none";
            }else{
                document.getElementById("canvasdiv").style.display = "block";
            }
        }
        function aktualizacia2(){
            if(document.getElementById("graf1").checked == false){
                document.getElementById("graph").style.display = "none";
            }else{
                document.getElementById("graph").style.display = "block";
            }
        }
        function aktualizacia3(){
            if(document.getElementById("graf2").checked == false){
                document.getElementById("graph2").style.display = "none";
            }else{
                document.getElementById("graph2").style.display = "block";
            }
        }
    </script>
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Menu</a>
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/index.php"><?php echo $lang['nav1']; ?></a>
            <a class="nav-item nav-link active" href="http://147.175.121.210:8084/FINAL/tlmic/tlmenie_index.php"><?php echo $lang['nav2']; ?><span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/gulicka/gulicka.php"><?php echo $lang['nav3']; ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/kyvadlo/pendulum.php"><?php echo $lang['nav4']; ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/lietadlo/lietadlo.php"><?php echo $lang['nav5']; ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/statistika.php"><?php echo $lang['nav6'] ?></a>
            <a class="nav-item nav-link" href="http://147.175.121.210:8084/FINAL/rozpis.php"><?php echo $lang['nav7'] ?></a>
        </div>
    </div>
</nav>

<h1><?php echo $lang['nav2']; ?></h1>

<form class="form-group" method="post" action="tlmenie_index.php">
    <div class="form-group">
    <input type="text" id="oAngle" name="oAngle" readonly value="<?php if( isset( $_POST['go'] )){ echo $_POST['nAngle'];} else { echo "0";} ?>"><br>
        <label for="nAngle">Value: </label><br>
        <input type="text" id="nAngle" name="nAngle" value="">[-400, 400]<br>
        <input class="btn btn-secondary" type="submit" name="go" value="<?php echo $lang['r']; ?>">
    </div>
</form>

<label for="animacia"><?php echo $lang['canvas']; ?></label><input type="checkbox" id="animacia" value="Canvas" checked="checked" onclick="aktualizacia1()">
<label for="graf1"><?php echo $lang['graf1']; ?></label><input type="checkbox" id="graf1" value="Graf1" checked="checked" onclick="aktualizacia2()">
<label for="graf2"><?php echo $lang['graf2']; ?></label><input type="checkbox" id="graf2" value="Graf2" checked="checked" onclick="aktualizacia3()">

<div id="canvasdiv">
    <canvas id="canvas" width="1000" height="300" style="border:1px solid #000000;"></canvas>
</div>
<div class="row">
<div class="col-sm-6" id="graph"></div>
<div class="col-sm-6" id="graph2"></div>
</div>
<?php
if (isset($_POST['go'])){
    $tlmenie = executeCommand(3,"octave qf tlmenie.txt", $_POST['nAngle']);

    $_SESSION['n'] += $_POST['oAngle'];
    if ($_SESSION['n'] >= 850) {
        $_SESSION['n'] = 850;
    }

    if ($_SESSION['n'] <= 0) {
        $_SESSION['n'] = 0;
    }

    echo $_POST['nAngle'] . " ";
    echo "\n" . $_SESSION['n'];
} else{
    $_SESSION['n'] = 0;
}

?>

<script>
    //draw X graph
    var trace1 = {
        x: [ <?php echo implode(", ", $tlmenie['time']);  ?>],
        y: [ <?php echo implode(", ", $tlmenie['x']); ?>],
        type: 'scatter'
    };
    var layout = {
        width: 500,
        height: 500
    };
    var data = [trace1];
    Plotly.newPlot('graph', data, layout);
    //draw Y graph
    var trace2 = {
        x: [ <?php echo implode(", ", $tlmenie['time']);  ?>],
        y: [ <?php echo implode(", ", $tlmenie['y']); ?>],
        type: 'scatter'
    };
    var layout = {
        width: 500,
        height: 500
    };
    var data1 = [trace2];
    Plotly.newPlot('graph2', data1, layout);
</script>

<script>
    let x1 = <?php echo json_encode($tlmenie['x'])?>;
    let y1 = <?php echo json_encode($tlmenie['y'])?>;
    let i = -1;
    const canvas = document.getElementById('canvas');

    const ctx = canvas.getContext('2d');

    function Circle (x, y, r, c) {
        this.x = x;
        this.y = y;
        this.r = r;
        this.c = c;

        this.draw = function () {
            ctx.beginPath();
            ctx.fillStyle = this.c;
            ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
            ctx.fill();
        };

        this.animate = function (i) {
            this.x = 25 + <?php echo $_SESSION['n'] ?>  + x1[i]*1;
            this.y = 100 + y1[i]*(-1);

            if (this.x > 885)
            {
                this.x = 885;
            }
            else if (this.x < 25)
            {
                this.x = 25;
            }

            this.draw();
        };
    }

    function Rect (x, y) {
        this.x = x;
        this.y = y;

        this.draw = function () {
            ctx.lineWidth = 5;
            ctx.beginPath();
            ctx.moveTo(10, 115);
            ctx.lineTo(this.x, this.y);
            ctx.stroke();
        };

        this.animate = function (i) {
            this.x = 900;
            this.y = 115+y1[i]*(-1);

            this.draw();
        };
    }

    function Rect2 (x, y) {
        this.x = x;
        this.y = y;

        this.draw = function () {
            ctx.beginPath();
            ctx.moveTo(900, 240);
            ctx.lineTo(this.x, this.y);
            ctx.stroke();
        };

        this.animate = function (i) {
            this.x = 900;
            this.y = 115+y1[i]*(-1);

            this.draw();
        };
    }

    function Line (x1,x2,y11,y2)
    {
        this.x1 = x1;
        this.x2 = x2;
        this.y11 = y11;
        this.y2 = y2;

        this.draw = function () {
            ctx.beginPath();
            ctx.moveTo(this.x1, this.y11);
            ctx.lineTo(this.x2, this.y2);
            ctx.stroke();
        };

        this.animate = function (i) {
            this.y11 = 115+y1[i]*(-1);
            this.y2 = 95+y1[i]*(-1);

            this.draw();
        };
    }


    let r = 15;
    let x = 25 + <?php echo $_SESSION['n'] ?> ;
    let y = 100;
    let c = 'red';
    let ball1 = new Circle(x, y, r, c);
    let rect1 = new Rect(900, 115);
    let rect2 = new Rect2(900, 115);
    let rect3 = new Line(10,10,115,95);
    let rect4 = new Line(900,900,115,95);

    function Update () {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        if (y1!=null) {
            if(y1.length-2 > i)
            {
                i=i+1;
                ball1.animate(i);
                rect1.animate(i);
                rect2.animate(i);
                rect3.draw();
                rect4.animate(i);
            }
            else {
                ball1.draw();
                rect1.draw();
                rect2.draw();
                rect3.draw();
                rect4.draw();
            }

        }
        else {
            ball1.draw();
            rect1.draw();
            rect2.draw();
            rect3.draw();
            rect4.draw();
        }
        //requestAnimationFrame(Update);
        setTimeout('Update()', 150);
    }

    Update();

</script>
<div id="footer" class="footer bg-dark text-center">
    <a href="tlmenie_index.php?lang=sk"><img border="0" src="sk.jpg" width="60" height="30"></a>
    | <a href="tlmenie_index.php?lang=en"><img border="0" src="en.jpg" width="60" height="30"></a>
</div>
</body>
</html>