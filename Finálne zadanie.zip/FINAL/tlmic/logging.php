<?php
include 'config.php';
    

/*  $Site = Site of origin of the request
    0 = Main site
    1 = Kyvadlo
    2 = Gulicka
    3 = Tlmic
    4 = Lietadlo    
    
    $Request = Command, which was executed by octave
    i.e.  "octave -qf lietadlo.m 0.2"
    
    #Error = Execution status of the request
    0 = Execution successful
    1 = Error
    2 = Warning
    3 = Invalid input values
    
    $Desc = Description of the error, based on $Error
    
*/

function databaseID($from){
    global $dbconf;
    $id = 1;

    $conn2 = mysqli_connect($dbconf['hostname'],$dbconf['username'],$dbconf['password'],$dbconf['dbname']);
    // Check connection
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

    $sql2 = "SELECT * FROM $from";
    $result = $conn2->query($sql2);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $id++;
        }
    }
    return $id;
}

    function log_Data ($Site, $Request, $Error) {
        global $servername;
        global $dbname;
        global $username;
        global $password;

        $id = databaseID("logs");
        $Desc = "";
        switch ($Error){
            case 0: 
                $Desc = "Script execution successful";
                break;
            case 1: 
                $Desc = "Script execution failed";
                break;
            case 2: 
                $Desc = "Warnings";
                break;
            case 3: 
                $Desc = "Invalid input values";
                break;
        }

        try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO login (site, request, time, value, description)
                VALUES ('$Site','$Request',CURRENT_TIME,'$Error','$Desc')";
            // use exec() because no results are returned
            $conn->exec($sql);
            //echo "New record created successfully";
        }
        catch(PDOException $e)
        {
            echo $sql . "<br>" . $e->getMessage();
        }
    }

    function mysqli_field_name($result, $field_offset) {
        $properties = mysqli_fetch_field_direct($result, $field_offset);
        return is_object($properties) ? $properties->name : null;
    }

    function csvExport() {
        global $dbconf;

        $conn = mysqli_connect($dbconf['hostname'],$dbconf['username'],$dbconf['password'],$dbconf['dbname']);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=data.csv');
        ob_end_clean();
        $output = fopen("php://output", "w");
        fputcsv($output, array('ID', 'SITE', 'REQUEST', 'TIME', 'VALUE', 'DESCRIPTION'));
        $query = "SELECT * from login ORDER BY ID ASC";
        $result = mysqli_query($conn, $query);
        while($row = mysqli_fetch_assoc($result))
        {
            fputcsv($output, $row);
        }
        fclose($output);
        exit();
    }
