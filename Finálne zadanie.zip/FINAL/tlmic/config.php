<?php

$servername = "localhost";
$username = "xdomorakm";
$password = "focal_pasame";
$dbname = "final";

$dbconf = array(
    'hostname' => 'localhost',
    'username' => 'xdomorakm',
    'password' => 'focal_pasame',
    'dbname' => 'final',
);