<?php

function checkInput($newR)
{
    if (is_numeric($newR))
    {
        return true;
    }
    else{
        return false;
    }
}

function executeCommand($site, $command, $r)
{
    //include 'logging.php';

    $time = array();
    $x = array();
    $y = array();
    $cmd = "octave -qf tlmenie.txt " . $r;
    if (checkInput($r)) {
        exec($cmd, $output);
        log_Data($site, $cmd, 0);
    }
    else {
        log_Data($site, $cmd, 3);
    }
    foreach ($output as $line){
        $trimmed = explode(" ", trim($line));
        $filtered = array_filter($trimmed);
        $coords = array_values($filtered);
        //echo "t:" . $coords[0] . "x1:" . $coords[1] . " x3:" . $coords[2] . "<br>";
        array_push($time, $coords[0]);
        array_push($y, $coords[2]);
        array_push($x, $coords[1]);
    }

    $tlmenie = array('time' => $time, 'x' => $x, 'y' => $y);

    //echo "t:" . $tlmenie['Time'][2] . " x3:" . $tlmenie['Angle'][2] . "<br>";

    return $tlmenie;

}